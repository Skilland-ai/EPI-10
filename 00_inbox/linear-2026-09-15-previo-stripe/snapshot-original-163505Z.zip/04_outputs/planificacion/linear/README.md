# Planificación de EPI10 en Linear

**Instantánea consultada: 2026-09-15 16:35:05 UTC.** Proyecto: [EPI10 Salud MVP](https://linear.app/skilland/project/epi10-salud-mvp-928812c268de), ID `965a6f5b-d9a2-41cb-8983-266318ca939a`.

El horizonte registrado va del **31 de agosto al 13 de noviembre de 2026**: MVP integrado, validado y listo para demo. El despliegue productivo, mantenimiento y Fase 2 se planifican después. TellmeGen/laboratorio sigue externo y manual; Stripe gestiona el pago, Healthie la experiencia del cliente, Odoo el caso operativo y Copilot los borradores con revisión humana.

## Entradas

- [Punto de situación y nueva planificación](00_situacion.md): objetivo, límites y principios.
- [Roadmap funcional](01_roadmap_funcional.md): 7 bloques, 31 subbloques y referencias T001–T106.
- [Roadmap cronológico](02_roadmap_cronologico.md): 8 oleadas y 11 semanas.
- [Inventario de las 106 tareas](tareas.md): enlaces reales, oleada, estado, responsable, fecha individual y archivado.
- [Sandbox por módulos](../../modulos/README.md): documentación y ejecución local; Stripe es el foco de la sesión.

Los tres documentos fuente fueron actualizados en Linear el **7 de septiembre de 2026**; cada copia conserva el timestamp, URL e ID exactos. El contenido fuente se mantiene íntegro bajo su encabezado de procedencia.

## Calendario registrado

Fechas originales del roadmap y deadlines actuales de los hitos, sin reprogramación local. Los conteos de tareas son los consultados el 15 de septiembre de 2026.

| Oleada / milestone | Periodo original | Deadline del hito | Tareas roadmap | Sin archivar | Archivadas |
| --- | --- | --- | ---: | ---: | ---: |
| OL1 - Apertura de frentes | 2026-08-31 — 2026-09-04 | 2026-09-04 | 12 | 10 | 2 |
| OL2 - Artefactos y diagnóstico | 2026-09-07 — 2026-09-11 | 2026-09-11 | 11 | 11 | 0 |
| OL3 - Validación y preparación | 2026-09-14 — 2026-09-18 | 2026-09-18 | 22 | 22 | 0 |
| OL4 - Specs y cierre de Stripe | 2026-09-21 — 2026-09-25 | 2026-09-25 | 13 | 13 | 0 |
| OL5 - Construcción funcional | 2026-09-28 — 2026-10-09 | 2026-10-09 | 18 | 18 | 0 |
| OL6 - Superficies de integración y QA individual | 2026-10-12 — 2026-10-23 | 2026-10-23 | 14 | 14 | 0 |
| OL7 - Integración completa | 2026-10-26 — 2026-11-06 | 2026-11-06 | 9 | 9 | 0 |
| OL8 - Cierre técnico del MVP | 2026-11-09 — 2026-11-13 | 2026-11-13 | 7 | 7 | 0 |
| **Total** | **11 semanas** | **2026-11-13** | **106** | **104** | **2** |

**Fechas de tarea y de oleada son datos distintos.** Nueve tareas de OL1 tienen fecha individual 2026-09-11, aunque el deadline de OL1 sigue siendo 2026-09-04; las otras 97 tareas no tienen fecha individual. El inventario conserva esos valores, sin completar fechas por herencia del hito.

## Estado registrado en esta instantánea

- **104 sin archivar:** 96 `Todo`, 6 `In Progress`, 2 `Done`.
- **2 archivadas:** SKI-34 (`Todo`) y SKI-35 (`Done`), ambas en OL1.
- **Responsables:** solo SKI-1 está asignada, a Raúl. Las otras 105 no tienen responsable; 103 de ellas están sin archivar.

Estas cifras describen el tablero consultado. **Unknown:** cuánto trabajo realizado fuera de Linear está pendiente de registrar; motivo del archivado de SKI-34 y SKI-35. El campo de archivado no sustituye al estado y no acredita por sí mismo finalización.

## Fuente de verdad y actualización

Linear mantiene la planificación, los responsables y los estados. Esta carpeta es una copia fechada para trabajar desde el repo; las decisiones y evidencias de ejecución se registran en [módulos](../../modulos/README.md). El material anterior del repo se conserva como histórico cuando difiere de este calendario. Una nota local no cambia automáticamente Linear.

1. Leer el proyecto y sus tres documentos por ID; consultar los ocho milestones.
2. Listar tareas del proyecto con `includeArchived=true`, solicitando explícitamente `id`, `uuid`, `title`, `projectMilestone`, `status`, `statusType`, `url`, `assignee`, `assigneeId`, `dueDate`, `archivedAt`, `createdAt` y `updatedAt`. Recorrer cursores hasta `hasNextPage=false`.
3. Contrastar con `includeArchived=false` y `assignee="null"`. Un campo omitido no equivale automáticamente a un valor vacío; verificarlo o marcarlo `Unknown`.
4. Sustituir las copias conservando íntegro el contenido fuente y actualizar su procedencia. Regenerar el inventario por ID real y milestone; mantener independientes las fechas individuales y de oleada.
5. Actualizar fecha, cifras y diferencias; comprobar enlaces locales y correspondencia entre las tareas del roadmap y Linear. Registrar cambios de ejecución en el módulo correspondiente. No reprogramar ni marcar tareas hechas por inferencia.

## Verificación de esta entrega

- Tres contenidos copiados íntegros, con ID, URL y fechas fuente/consulta.
- 106 IDs y URLs de tarea únicos, asociados uno a uno a T001–T106 por título y oleada.
- 8 milestones; suma por oleada igual al roadmap: 12 + 11 + 22 + 13 + 18 + 14 + 9 + 7 = 106.
- Consultas completas: una página de 106 tareas, una de 104 sin archivar y una de 105 sin responsable; todas con `hasNextPage=false`.
- Campos `dueDate` y `archivedAt` solicitados y devueltos para las 106 tareas; responsables ausentes contrastados mediante filtro.

La verificación cubre la incorporación de la planificación. No declara completadas tareas del MVP ni pruebas del mockup.

